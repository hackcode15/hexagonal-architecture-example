package com.app.example1hexagonal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Example1hexagonalApplicationTests {

	@Test
	void contextLoads() {
	}

}
