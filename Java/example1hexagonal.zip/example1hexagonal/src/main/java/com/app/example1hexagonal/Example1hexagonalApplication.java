package com.app.example1hexagonal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Example1hexagonalApplication {

	public static void main(String[] args) {
		SpringApplication.run(Example1hexagonalApplication.class, args);
	}

}
