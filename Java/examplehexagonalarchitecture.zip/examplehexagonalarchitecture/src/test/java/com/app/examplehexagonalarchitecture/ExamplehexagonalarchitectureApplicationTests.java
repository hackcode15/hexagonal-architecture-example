package com.app.examplehexagonalarchitecture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamplehexagonalarchitectureApplicationTests {

	@Test
	void contextLoads() {
	}

}
